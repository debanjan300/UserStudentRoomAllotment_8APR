package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


import com.example.demo.entity.Room;

import com.example.demo.model.RoomRepository;


@Component("rs")
public class RoomService {
	@Autowired
	RoomRepository roomRepository;
	public Room create(Room room) {
		return roomRepository.save(room);
	}
	public List<Room> read() {
		return roomRepository.findAll();
	}
	public Room read(Long roomId)
	{
		return roomRepository.findById(roomId).get();
	}
	
	public Room update(Room room) {
		return roomRepository.save(room);
	}
	public void delete(Long roomId) {
		Room room = roomRepository.findById(roomId).get();
		roomRepository.delete(room);
	}

}
