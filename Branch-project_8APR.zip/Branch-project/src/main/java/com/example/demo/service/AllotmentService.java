package com.example.demo.service;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.entity.Allotment;
import com.example.demo.model.AllotmentRepository;



@Component("as")
public class AllotmentService {
	@Autowired
	private AllotmentRepository allotmentRepo;
	
	public Allotment create(Allotment allotment) {
		return allotmentRepo.save(allotment);
	}
	
	public List<Allotment> read() {
		return allotmentRepo.findAll();
	}
	public Allotment read(Long allotmentId) {
		return allotmentRepo.findById(allotmentId).get();
	}
	public Allotment update(Allotment allotment) {
		return allotmentRepo.save(allotment);
	}
	public void delete(Long allotmentId) {
		allotmentRepo.delete(read(allotmentId));
	}
	

}
