import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class RoomService {

  url:string='http://localhost:8080/room/';
  constructor(private http:HttpClient) { }
  addRoom(room:any)
  {
    // alert('Service:adding branch');
    return this.http.post(this.url,room);
  }
  modifyRoom(room:any)
  {
    // alert('Service:modifying branch');
    return this.http.put(this.url,room);
  }
  deleteRoom(roomId:any)
  {
    // alert('Service:deleting branch'+bid);
    return this.http.delete(this.url+roomId);
  }
  getAllRooms()
  {
    return this.http.get(this.url);
  }
  findRoomById(roomId:any)
  {
    return this.http.get(this.url+roomId);
  }
}
