import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { Student } from '../student';
import { User } from '../user';
import { UserService } from '../user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  user:User=new User();
  
  loginForm:any;
  status:any;
  constructor(private fb:FormBuilder, private router:Router, private us:UserService) { 
    this.loginForm=this.fb.group({
      userName:[''],
      password:[''],
      showPassword:[''],
      rememberMe:[true]
    });
  }

  ngOnInit(): void {
    
    var rememberMe=this.loginForm.controls.rememberMe.value;
    if(rememberMe)
    {
      var userName=localStorage.getItem("userName");
      if(userName!=null)
        this.loginForm.controls.userName.value=userName;

        var password=localStorage.getItem("password");
        if(password!=null)
          this.loginForm.controls.password.value=password;

    }
    //window.location.reload();
  }
  fnCall()
  {
    this.us.method1().subscribe((data)=>{
      console.log(data);
    });
    console.log("DONE!!");
  }
  fnCall2()
  {
    this.us.method2().subscribe((data)=>{
      console.log(data);
    });
    this.us.method2().subscribe((data)=>{
      console.log(data);
    });
    console.log("DONE");
  
    
  }

  fnLogin()
  {
    var userName=this.loginForm.controls.userName.value;
    var password=this.loginForm.controls.password.value;
    var rememberMe=this.loginForm.controls.rememberMe.value;
    
    if(rememberMe)
    {
      localStorage.setItem("userName",userName);
      localStorage.setItem("password",password);
    }
    else{
      localStorage.removeItem("userName");
      localStorage.removeItem("password");
    }
    console.log(userName+":"+password);
    const formData=new FormData();
    formData.append('userName',userName);
    formData.append('password',password);
    this.us.validateLogin(formData).subscribe((data)=>{ //here the data is an user object
      console.log(data);
    
      if(data==null)
        this.status="Login failed!";
      else
      { 
        //loggedUserName
        localStorage.setItem("loggedUserName",userName);
        this.user=<User>data;
        localStorage.setItem("loggedRole",this.user.role);
        localStorage.setItem("loggedFirstName",this.user.firstName);
      
        // check if the user filled the necessary details or not
        //if filled, enable menu item
        //if not filled, disable menu item

        
        
        //this.router.navigate([{outlets:{'col3':['home']}}]);
        this.router.navigateByUrl('/(col3:home)');
        //alert(this.user.role);
      
      }
    });
  }

}
