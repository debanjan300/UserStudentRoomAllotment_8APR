import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class BranchService {

  url:string='http://localhost:8080/branch/';
  constructor(private http:HttpClient) { }

  addBranch(branch:any)
  {
    // alert('Service:adding branch');
    return this.http.post(this.url,branch);
  }
  modifyBranch(branch:any)
  {
    // alert('Service:modifying branch');
    return this.http.put(this.url,branch);
  }
  deleteBranch(bid:string)
  {
    // alert('Service:deleting branch'+bid);
    return this.http.delete(this.url+bid);
  }
  getAllBranches()
  {
    return this.http.get(this.url);
  }
  findBranchById(bid:string)
  {
    return this.http.get(this.url+bid);
  }
}
