import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { AllotmentService } from '../allotment.service';

@Component({
  selector: 'app-allotment',
  templateUrl: './allotment.component.html',
  styleUrls: ['./allotment.component.css']
})
export class AllotmentComponent implements OnInit {
  // allotmentForm:any;
  allotments:any;
 // roomId:any;
  //studentId:any;

  constructor(private as:AllotmentService,private router:Router) { }

  ngOnInit(): void {
    var loggedUserName=localStorage.getItem("loggedUserName");
    var loggedRole=localStorage.getItem("loggedRole");
  //  this.roomId=localStorage.getItem("roomId");
   // this.studentId=localStorage.getItem("studentId");
   // alert(this.roomId);
  //  console.log(this.roomId);
  // console.log(this.studentId);
    
    if(loggedUserName==null)
    {
      alert("You have not logged in. Click OK to Login")
    this.router.navigateByUrl('/(col3:Login)');
    }
    else{
      if(loggedRole=="User"){
        alert("You are an "+loggedRole+". Click OK to continue.");
        this.router.navigateByUrl('/(col3:home)');
      }
      else{
        
    this.getAllAllotment();
        }
    }
  }
  getAllAllotment(){
    this.as.getAllAllotment().subscribe((data)=>{
      console.log(data);
      this.allotments=data;
    });
  }

  fnApprove(){
    alert("Approved..")
  }
  fnReject(allotmentId:any)
  {
    this.as.deleteAllotment(allotmentId).subscribe((data)=>{
      console.log(data);
      this.getAllAllotment();
    });
  }

}
