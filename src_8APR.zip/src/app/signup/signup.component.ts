import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../user.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  signupForm:any;
  gotp:any;
  otpError:any;
  selectedFile:any;
  constructor(private fb:FormBuilder, private us:UserService, private router:Router) { 
    this.signupForm=this.fb.group({
      userName:[''],
      password:['password'],
      cpassword:['password'],
      firstName:['Deba'],
      lastName:['Dutta'],
      dateOfBirth:['1999-01-01'],
      emailAddress:['duttadebanjan300@gmail.com'],
      generatedOtp:[''],
      enteredOtp:['1111'],
      role:['User'],
      status:['pending'],
      photo:[]
    });
  }

  ngOnInit(): void {
  }

  onFileChanged(event:any)
  {
    this.selectedFile=event.target.files[0];
    console.log(JSON.stringify(this.selectedFile));
  }
  addUser()
  {
    var eotp=this.signupForm.controls.enteredOtp.value;
    alert('comparing '+eotp+' with '+this.gotp);
   // alert('adding...');
   if(eotp!=this.gotp)
   {
    this.otpError="Entered otp is invalid!";
     return;
   }
    console.log(this.signupForm.value);
    var formData=new FormData();

    formData.append('userName',this.signupForm.controls.userName.value);
    formData.append('password',this.signupForm.controls.password.value);
    formData.append('firstName',this.signupForm.controls.firstName.value);
    formData.append('lastName',this.signupForm.controls.lastName.value);
    formData.append('dateOfBirth',this.signupForm.controls.dateOfBirth.value);
    formData.append('emailAddress',this.signupForm.controls.emailAddress.value);
    formData.append('role',this.signupForm.controls.role.value);
    formData.append('status',this.signupForm.controls.status.value);
    formData.append('photo',this.selectedFile,this.selectedFile.name);
    this.us.addUser(formData).subscribe(data=>{
      console.log(data);
      this.router.navigateByUrl('/(col3:login)');
    });
  }

  fnGenerateOtp()
  {
    
    var emailAddress=this.signupForm.controls.emailAddress.value;
    console.log(emailAddress);
    this.us.generateOtp(emailAddress).subscribe((data)=>{
      console.log(data);
      this.gotp=data;      
    });
    // this.signupForm.controls.generatedOtp.value=this.gotp;
  }

}
