import { stringify } from '@angular/compiler/src/util';
import { Component, DoCheck, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { Student } from '../student';
import { StudentService } from '../student.service';
import { User } from '../user';
import { UserService } from '../user.service';

@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css']
})
export class StudentComponent implements OnInit, DoCheck {
  student:Student=new Student();
  role:string="";
  studentForm: any;
  students: any;
  userName:string|any='';
  
  
  constructor(private fb:FormBuilder, private ss:StudentService, private us:UserService, private router:Router) {
    this.studentForm = this.fb.group({
      studentId:[''],
      userName:[''],
      guardianFirstName:[''],
      guardianLastName:[''],
      guardianMobile:[''],
    });
   }
  ngDoCheck(): void {
   var strRole= localStorage.getItem("loggedRole");
   if(strRole!=null)
    this.role=strRole;
    else
      this.role="";
  }

  ngOnInit(): void {
    var loggedUserName=localStorage.getItem("loggedUserName");
    if(loggedUserName==null)
    {
      alert("You have not logged in. Click OK to Login")
      this.router.navigateByUrl('/(col3:Login)');
    }
    else
    this.router.navigateByUrl('/(col2:student)');

    var userName=localStorage.getItem("userName");
    this.userName=userName;
    //alert(userName);
    this.getAllStudents();
  }
  getAllStudents() {
    this.ss.getAllStudents().subscribe((data) => {
      console.log(data);
      this.students = data;
    });
  }
  fnAdd() {  

    var student = this.studentForm.value;
//obtain an user object from rest api and fill this user to the student object and then send
    var user=new User();
    this.us.findUserByUserName(this.userName).subscribe((data)=>{
      user=<User><any>data;
      console.log("Found user:");
      console.log(data);
      console.log(user);
      student.user=user;
      console.log("Sending student as :"+JSON.stringify(student))
      // this.bs.addBranch(branch).subscribe(this.fnCallBack);    
      this.ss.addStudent(student).subscribe((data) => {
        console.log(data);
        this.getAllStudents();
       var sid:string;
        sid=<any>this.student.studentId;
        localStorage.setItem("studentId",sid)
      });
    });
   
  }
  fnModify() {
    var student = this.studentForm.value;
    this.ss.modifyStudent(student).subscribe((data) => {
      console.log(data);
      this.getAllStudents();
    });
  }
  fnDelete() {
    var studentId = this.studentForm.controls.studentId.value;
    this.ss.deleteStudent(studentId).subscribe((data) => {
      console.log(data);
      this.getAllStudents();
    });
  }

}
