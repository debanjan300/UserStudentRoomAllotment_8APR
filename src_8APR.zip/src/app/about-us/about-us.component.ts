import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-about-us',
  templateUrl: './about-us.component.html',
  styleUrls: ['./about-us.component.css']
})
export class AboutUsComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit(): void {
    var loggedUserName=localStorage.getItem("loggedUserName");
    
    if(loggedUserName==null)
    {
      alert("You have not logged in. Click OK to Login")
    this.router.navigateByUrl('/(col3:Login)');
    }
    else{
     
      this.router.navigateByUrl('/(col1:about)');
    }
  }

}
