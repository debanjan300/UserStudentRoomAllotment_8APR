import { Component, DoCheck, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { Allotment } from '../allotment';
import { AllotmentService } from '../allotment.service';
import { Room } from '../room';
import { RoomService } from '../room.service';
import { Student } from '../student';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-room',
  templateUrl: './room.component.html',
  styleUrls: ['./room.component.css']
})
export class RoomComponent implements OnInit, DoCheck {
  room: Room = new Room();
  student:Student|any=null;
  role: string = "";
  roomForm: any;
  rooms: any;
  constructor(private fb: FormBuilder, private rs: RoomService, private router: Router, private as: AllotmentService, private ss: StudentService) {
    this.roomForm = this.fb.group({
      roomId: [''],
      roomType: [''],
      roomOccupancy: [''],
      fee: [''],
      bookingStatus: ['Available']
    });
  }
  fnBlockUser()
  {
    var userName: string | any = localStorage.getItem('loggedUserName');
    this.ss.findStudentByUserName(userName).subscribe((data)=>{
      console.log("Romm component DoCheck DATA: "+data);
      // alert(data);
      this.student=data;
      //  if(data==null)
      // {
      //      alert("Fill your student details first!!");
      //      this.router.navigateByUrl('/(col2:student)');
      //   }
      //    return;
    });
  }
  ngDoCheck(): void {
    
    

    var strRole = localStorage.getItem("loggedRole");
    if (strRole != null)
      this.role = strRole;
    else
      this.role = "";
    console.log("Room component do check method:" + this.role);


  }

  ngOnInit(): void {
    this.fnBlockUser();
    
    var loggedUserName = localStorage.getItem("loggedUserName");
    if (loggedUserName == null) {
      alert("You have not logged in. Click OK to log in.");
      this.router.navigateByUrl('/(col3:Login)');
    }
    else
      this.router.navigateByUrl('/(col2:room)');
    this.loadRooms();
  }

  loadRooms() {
    this.rs.getAllRooms().subscribe((data) => {
      console.log(data);
      this.rooms = data;

    });
  }
  fnAdd() {
    var room = this.roomForm.value;
    this.rs.addRoom(room).subscribe((data) => {
      console.log(data);
      this.loadRooms();
    });
  }
  fnModify() {
    var room = this.roomForm.value;
    this.rs.modifyRoom(room).subscribe((data) => {
      console.log(data);
      this.loadRooms();
    });
  }
  fnDelete() {
    var roomId = this.roomForm.controls.roomId.value;
    // alert(roomId);
    this.rs.deleteRoom(roomId).subscribe((data) => {
      console.log(data);
      this.loadRooms();
    });
  }
  fnBook(rid: string) {
    //alert("Booking....");
    var allotment = new Allotment();
    //fill the details

    var room: Room = new Room();
    var student: Student = new Student();
    //find room by roomId                   http://localhost:8080/room/1011
    this.rs.findRoomById(rid).subscribe((data) => {
      console.log("Room component, fnBook, found room by id:" + rid + " is : " + JSON.stringify(data));
      room = <any>data;
      allotment.room = room;
      allotment.allocationDate = new Date();
      //find the student object by userName;    http://localhost:8080/student/findByUserName/d001
      var userName: string | any = localStorage.getItem('loggedUserName');
      this.ss.findStudentByUserName(userName).subscribe((data) => {
        console.log('Room component fnBook method, received student object is ' + JSON.stringify(data));
        var student: Student = <any>data;
        allotment.student = student;
        //add the allotment to the db
        allotment.status="pending";
        this.as.addAllotment(allotment).subscribe((data) => {
          console.log("Response after adding allotment is :" + JSON.stringify(data));
        })
      });

    });
  }

}
